import 'package:flutter/material.dart';

class DuesPage extends StatelessWidget {
  const DuesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DuesPage'),
      ),
      body: const Center(
        child: Text('Welcome to DuesPage!'),
      ),
    );
  }
}
