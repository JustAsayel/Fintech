
class Loan {
  String name;
  double amount;
  String status; // "Pending", "Approved", "Rejected"
  DateTime dueDate;
  bool isLinked;

  Loan({
    required this.name,
    required this.amount,
    required this.status,
    required this.dueDate,
    this.isLinked = false,
  });
}
