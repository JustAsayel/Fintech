// Enroll user in new loan flow
