import 'package:flutter/material.dart';

class LoanDetailPage extends StatelessWidget {
  final String title;
  const LoanDetailPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Color(0xFF0A2D52),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Loan Overview", style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            const Text("Installments: \$500/month"),
            const Text("Next payment due: 10 Aug 2025"),
            const Text("Daily interest tracker: \$1.20/day"),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: const Text("Make Monthly Payment"),
            )
          ],
        ),
      ),
    );
  }
}