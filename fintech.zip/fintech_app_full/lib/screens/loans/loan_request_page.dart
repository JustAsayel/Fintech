import 'package:flutter/material.dart';
import 'thank_you_page.dart';

class LoanRequestPage extends StatefulWidget {
  const LoanRequestPage({super.key});

  @override
  State<LoanRequestPage> createState() => _LoanRequestPageState();
}

class _LoanRequestPageState extends State<LoanRequestPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _amountController = TextEditingController();

  String? _type;
  bool _linkLoan = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Request Loan"),
        backgroundColor: Color(0xFF0A2D52),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: "Loan Type"),
                items: const [
                  DropdownMenuItem(value: "Education", child: Text("Education")),
                  DropdownMenuItem(value: "Car", child: Text("Car")),
                  DropdownMenuItem(value: "Home", child: Text("Home")),
                ],
                onChanged: (value) => setState(() => _type = value),
                validator: (value) => value == null ? "Select a type" : null,
              ),
              TextFormField(
                controller: _amountController,
                decoration: const InputDecoration(labelText: "Loan Amount"),
                keyboardType: TextInputType.number,
                validator: (value) =>
                    value == null || value.isEmpty ? "Enter amount" : null,
              ),
              SwitchListTile(
                value: _linkLoan,
                onChanged: (val) => setState(() => _linkLoan = val),
                title: const Text("Link with existing loan"),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const ThankYouPage()));
                  }
                },
                child: const Text("Submit Request"),
              )
            ],
          ),
        ),
      ),
    );
  }
}