// Confirm subscription to loan plan
