
import 'package:flutter/material.dart';

class LoanPaymentPage extends StatelessWidget {
  const LoanPaymentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Loan Payment"), backgroundColor: Color(0xFF0A2D52)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text("Monthly Payment: \$200", style: TextStyle(fontSize: 18)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Payment Successful")));
                Navigator.pop(context);
              },
              child: const Text("Pay Now"),
            ),
          ],
        ),
      ),
    );
  }
}
