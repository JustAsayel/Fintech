import 'package:flutter/material.dart';
import 'loan_request_page.dart';
import 'loan_detail_page.dart';

class LoanDashboard extends StatelessWidget {
  const LoanDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Loan Dashboard"),
        backgroundColor: Color(0xFF0A2D52),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _loanCard(context, "Education Loan", "Approved", 12000, 0.02),
          _loanCard(context, "Car Loan", "Pending", 8500, 0.015),
          _loanCard(context, "Home Loan", "Linked", 23000, 0.012),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text("Request New Loan"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const LoanRequestPage()));
            },
          )
        ],
      ),
    );
  }

  Widget _loanCard(BuildContext context, String title, String status,
      double amount, double interest) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 4,
      child: ListTile(
        title: Text(title),
        subtitle: Text("Status: $status\nAmount: \$${amount.toStringAsFixed(2)}"),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("APR: ${(interest * 100).toStringAsFixed(1)}%"),
            if (status == "Pending")
              TextButton(
                onPressed: () {},
                child: const Text("Cancel", style: TextStyle(color: Colors.red)),
              )
          ],
        ),
        onTap: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => LoanDetailPage(title: title)));
        },
      ),
    );
  }
}