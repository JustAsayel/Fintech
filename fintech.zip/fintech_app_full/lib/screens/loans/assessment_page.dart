// AI-based financial eligibility check page
