package com.example.fintech_app_full

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
